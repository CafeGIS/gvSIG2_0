/* I'm not sure why tiff.h includes this instead of tif_config.h */

#include "gdal/tif_config.h"
