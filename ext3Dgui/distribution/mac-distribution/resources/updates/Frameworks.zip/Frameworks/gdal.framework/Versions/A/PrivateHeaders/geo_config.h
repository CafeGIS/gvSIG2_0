/* geo_config.h.  Generated automatically by configure.  */
#ifndef GEO_CONFIG_H
#define GEO_CONFIG_H

#include "gdal/cpl_config.h"

#endif /* ndef GEO_CONFIG_H */
