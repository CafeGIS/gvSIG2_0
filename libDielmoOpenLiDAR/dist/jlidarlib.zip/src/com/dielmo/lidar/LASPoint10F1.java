/* DielmoOpenLiDAR
 *
 * Copyright (C) 2008 DIELMO 3D S.L. (DIELMO) and Infrastructures  
 * and Transports Department of the Valencian Government (CIT)
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
 * MA  02110-1301, USA.
 *
 * For more information, contact:
 *
 * DIELMO 3D S.L.
 * Plaza Vicente Andr�s Estell�s 1 Bajo E
 * 46950 Xirivella, Valencia
 * SPAIN
 *   
 * +34 963137212
 * dielmo@dielmo.com
 * www.dielmo.com
 * 
 * or
 * 
 * Generalitat Valenciana
 * Conselleria d'Infraestructures i Transport
 * Av. Blasco Ib��ez, 50
 * 46010 VALENCIA
 * SPAIN
 *
 * +34 963862235
 * gvsig@gva.es
 * www.gvsig.gva.es
 */

/*
 * AUTHORS (In addition to DIELMO and CIT):
 *  
 */

package com.dielmo.lidar;

import java.nio.ByteBuffer;
import java.sql.Types;

import com.hardcode.gdbms.engine.values.DoubleValue;
import com.hardcode.gdbms.engine.values.IntValue;
import com.hardcode.gdbms.engine.values.Value;
import com.hardcode.gdbms.engine.values.ValueFactory;
import com.iver.cit.gvsig.fmap.drivers.FieldDescription;
import com.iver.utiles.bigfile.BigByteBuffer2;


/**
 * LAS point that implement the LAS point data version LAS1.0
 * in format 1
 * 
 * @author Oscar Garcia
 */
public class LASPoint10F1 extends LASPoint10F0{	
	
	/**
	 * The GPS time is the double floating point time tag value at which
	 * the point was acquired.
	 */
	private double timeGPS;
	
	/**
	 * Default constructor, without arguments.
	 * Initializes all components to zero.
	 */ 
	public LASPoint10F1() {
		super();
		timeGPS = 0;
		sizeFormat = 28;
	}
	
	
	/**
	 * Get GPS time as double floating point time tag value at which
	 * the point was acquired.
	 */
	public double getTimeGPS() {
		return timeGPS;
	}
	
	/**
	 * Set GPS time to double floating point time tag value at which
	 * the point was acquired.
	 */
	public void setTimeGPS(double tGPS) {
		timeGPS = tGPS;
	}
	
	
	/**
	 * Read a point of LAS file
	 * 
	 * @param input input file to read
	 * @param Offset Offset to data
	 * @param index index of points to read
	 * @return true if success else return false 
	 */
	public void readPoint(BigByteBuffer2 input, LidarHeader hdr, long index) {
	
		try{
			if(index>hdr.getNumPointsRecord() || index < 0) {
				throw new UnexpectedPointException("Out of index"); 
			}
			
			byte[] punto = new byte[getSizeFormat()];
			
			input.position(hdr.getOffsetData()+getSizeFormat()*index);
		    input.get(punto);
			
		    setX(ByteUtilities.arr2Int(punto, 0));
		    setY(ByteUtilities.arr2Int(punto, 4));
		    setZ(ByteUtilities.arr2Int(punto, 8));
		    setIntensity(ByteUtilities.arr2Unsignedshort(punto, 12));
		    
		    setReturnNumber((byte)(punto[14] & 0x07)); // 3 primeros bits del byte 14
		    setNumberOfReturn((byte)((punto[14] & 0x38) >> 3));  // 3 siguintes bits
		    setScanDirectionFlag((byte)((punto[14] & 0x40) >> 6)); // 1 bit
		    setEdgeOfFlightLine((byte)((punto[14] & 0x80) >> 7)); // 1 bit
		    
		    setClassification((char)(punto[15] & 0XFF));
		    setScanAngleRank((punto[16]));
		    setFileMarker((char)(punto[17] & 0XFF));
		    setUserBitField(ByteUtilities.arr2Unsignedshort(punto, 18));
			timeGPS = ByteUtilities.arr2Double(punto, 20);
		} catch (UnexpectedPointException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * get field value by index:
	 * 
	 * 0 return X
	 * 1 return Y
	 * 2 return Z
	 * 3 return intensity
	 * 4 return returnNumber
	 * 5 return numberOfReturn
	 * 6 return scanDirectionFlag
	 * 7 return edgeOfFlightLine
	 * 8 return classification
	 * 9 return scanAngleRank
	 * 10 return fileMarker
	 * 11 return UserBitField
	 * 12 return Time GPS
	 * 
	 * @param bb byte buffer of data 
 	 * @param indexField index of field
	 * @param hdr LiDAR header
	 * @param index asked point index. (row)
	 * @return Value of row and column indicated
	 */	
	public Value getFieldValueByIndex(BigByteBuffer2 bb, int indexField,
			LidarHeader hdr, long index) {
		
		readPoint(bb, hdr, index);
	
		switch(indexField) {
		
			case 0:
				return ValueFactory.createValue(getX()*hdr.getXScale()+hdr.getXOffset());
				
			case 1: 
				return ValueFactory.createValue(getY()*hdr.getYScale()+hdr.getYOffset());
				
			case 2:
				return ValueFactory.createValue(getZ()*hdr.getZScale()+hdr.getZOffset());
			
			case 3:
				return ValueFactory.createValue(getIntensity());
				
			case 4:
				return ValueFactory.createValue(getReturnNumber());
				
			case 5:
				return ValueFactory.createValue(getNumberOfReturn());
				
			case 6:
				return ValueFactory.createValue(getScanDirectionFlag());
			
			case 7:
				return ValueFactory.createValue(getEdgeOfFlightLine());
				
			case 8:
				return ValueFactory.createValue(getClassification());
				
			case 9:
				return ValueFactory.createValue(getScanAngleRank());
				
			case 10:

				return ValueFactory.createValue(getFileMarker());
				
			case 11:
				return ValueFactory.createValue(getUserBitField());
				
			case 12:
				return ValueFactory.createValue(getTimeGPS());
		}
		
		return null;
	}
	
	
	public Value getFieldValueByName(BigByteBuffer2 bb, String nameField, LidarHeader hdr,
			long index) {
		
		readPoint(bb, hdr, index);
		
		if(nameField.equalsIgnoreCase("X"))
			return ValueFactory.createValue(getX()*hdr.getXScale()+hdr.getXOffset());
		else if(nameField.equalsIgnoreCase("Y"))
			return ValueFactory.createValue(getY()*hdr.getYScale()+hdr.getYOffset());
		else if(nameField.equalsIgnoreCase("Z"))
			return ValueFactory.createValue(getZ()*hdr.getZScale()+hdr.getZOffset());
		else if(nameField.equalsIgnoreCase("Intensity"))
			return ValueFactory.createValue(getIntensity());
		else if(nameField.equalsIgnoreCase("Return_Number"))
			return ValueFactory.createValue(getReturnNumber());
		else if(nameField.equalsIgnoreCase("Number_of_Returns"))
			return ValueFactory.createValue(getNumberOfReturn());
		else if(nameField.equalsIgnoreCase("Scan_Direction_Flag"))
			return ValueFactory.createValue(getScanDirectionFlag());
		else if(nameField.equalsIgnoreCase("Edge_of_Flight_Line"))
			return ValueFactory.createValue(getEdgeOfFlightLine());
		else if(nameField.equalsIgnoreCase("Classification"))
			return ValueFactory.createValue(getClassification());
		else if(nameField.equalsIgnoreCase("Scan_Angle_Rank"))
			return ValueFactory.createValue(getScanAngleRank());
		else if(nameField.equalsIgnoreCase("File_Marker"))
			return ValueFactory.createValue(getFileMarker());
		else if(nameField.equalsIgnoreCase("User_Bit_Field"))
			return ValueFactory.createValue(getUserBitField());
		else if(nameField.equalsIgnoreCase("GPS_Time"))
			return ValueFactory.createValue(getTimeGPS());
		
		return null;
	}
	
	public FieldDescription[] getFieldDescription() {
		FieldDescription fieldDesc;
		FieldDescription[] fields;

		Value v;
		fields = new FieldDescription[13];

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("X");
		fieldDesc.setFieldType(Types.DOUBLE);
		fieldDesc.setFieldLength(20);
		fieldDesc.setFieldDecimalCount(3);
		v = ValueFactory.createValue((double)0.0);
		fieldDesc.setDefaultValue(v);
		fields[0] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Y");
		fieldDesc.setFieldType(Types.DOUBLE);
		fieldDesc.setFieldLength(20);
		fieldDesc.setFieldDecimalCount(3);
		v = ValueFactory.createValue((double)0.0);
		fieldDesc.setDefaultValue(v);
		fields[1] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Z");
		fieldDesc.setFieldType(Types.DOUBLE);
		fieldDesc.setFieldLength(20);
		fieldDesc.setFieldDecimalCount(3);
		v = ValueFactory.createValue((double)0.0);
		fieldDesc.setDefaultValue(v);
		fields[2] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Intensity");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(5);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[3] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Return_Number");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(1);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[4] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Number_of_Returns");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(1);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[5] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Scan_Direction_Flag");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(1);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[6] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Edge_of_Flight_Line");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(1);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[7] = fieldDesc;

		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Classification");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(3);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[8] = fieldDesc;
		
		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("Scan_Angle_Rank");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(3);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[9] = fieldDesc;
		
		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("File_Marker");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(3);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[10] = fieldDesc;
		
		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("User_Bit_Field");
		fieldDesc.setFieldType(Types.INTEGER);
		fieldDesc.setFieldLength(10);
		fieldDesc.setFieldDecimalCount(0);
		v = ValueFactory.createValue((int)0);
		fieldDesc.setDefaultValue(v);
		fields[11] = fieldDesc;
		
		fieldDesc = new FieldDescription();
		fieldDesc.setFieldName("GPS_Time");
		fieldDesc.setFieldType(Types.DOUBLE);
		fieldDesc.setFieldLength(20);
		fieldDesc.setFieldDecimalCount(5);
		v = ValueFactory.createValue((double)0.0);
		fieldDesc.setDefaultValue(v);
		fields[12] = fieldDesc;
		
		return fields;
	}
	
	public void WritePoint(ByteBuffer bb) {
		byte auxByte;
		byte[] punto = new byte[getSizeFormat()];

		
		// X bytes 0-4
		ByteUtilities.int2Arr(getX(), punto, 0);
		
		// Y bytes 4-8
		ByteUtilities.int2Arr(getY(), punto, 4);
		
		// bytes 8-12
		ByteUtilities.int2Arr(getZ(), punto, 8);
		
		// bytes 12-14
		ByteUtilities.unsignedShort2Arr(getIntensity(), punto, 12);
		
		// byte 14
		auxByte = getReturnNumber();
		auxByte |= (byte)((getNumberOfReturn()) << 3);
		auxByte |= (byte)((getScanDirectionFlag()) << 6);
		auxByte |= (byte)((getEdgeOfFlightLine()) << 7);
		punto[14] = auxByte;
		
		// byte 15
		punto[15] = (byte)((getClassification() & 0xFF));
		
		// byte 16
		punto[16] = (byte)((getScanAngleRank() & 0xFF));
		
		// byte 17
		punto[17] = (byte)((getFileMarker() & 0xFF));
		
		// bytes 18-20
		ByteUtilities.unsignedShort2Arr(getUserBitField(), punto, 18);
		
		// bytes 20-28
		ByteUtilities.double2Arr(getTimeGPS(), punto, 20);
		
		bb.put(punto);
	}
	
	/*
	 * Set Point from a row
	 * @see com.dielmo.gvsig.lidar.LidarPoint#setPoint(com.hardcode.gdbms.engine.values.Value[], com.dielmo.gvsig.lidar.LidarHeader)
	 */
	public void setPoint(Value[] row, LidarHeader hdr) {
		
		double auxX = ((DoubleValue)(row[0])).getValue();
		double auxY = ((DoubleValue)(row[1])).getValue();
		double auxZ = ((DoubleValue)(row[2])).getValue();
		
		setX((int) ((auxX-hdr.getXOffset())/hdr.getXScale()));
		setY((int) ((auxY-hdr.getYOffset())/hdr.getYScale()));
		setZ((int) ((auxZ-hdr.getZOffset())/hdr.getZScale()));
		
		setIntensity(((IntValue)(row[3])).getValue());
		setReturnNumber(((IntValue)(row[4])).byteValue());
		setNumberOfReturn(((IntValue)(row[5])).byteValue());
		setScanDirectionFlag(((IntValue)(row[6])).byteValue());
		setEdgeOfFlightLine(((IntValue)(row[7])).byteValue());
		setClassification((char) (((IntValue)(row[8])).byteValue() & 0xFF));
		setScanAngleRank(((IntValue)(row[9])).byteValue());
		setFileMarker((char) (((IntValue)(row[10])).byteValue() & 0xFF));
		setUserBitField(((IntValue)(row[11])).getValue());
		setTimeGPS(((DoubleValue)(row[12])).getValue());
	}
}
